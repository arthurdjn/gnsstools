# File: TP3_Orbite.py
# Creation: Saturday January 23rd 2021
# Author: Arthur Dujardin
# ------
# Copyright (c) 2021 Arthur Dujardin


# Imports
import os
import numpy as np
from gpstime import gpstime

# TP3
from gnss import Orbit


# Création d'un objet orbite
orbit = Orbit()
orbit.load_rinex_n("data/BRDC00IGS_R_20182850000_01D_MN.rnx")

# Objet Temps qui permet des conversion (secondes - mjd etc)
tgps = gpstime(yyyy=2018, doy=285, dsec=5435)
# Selection de la constellation
constellation = "G"
# Satellite
prn = 14
# Ephemeride associée
eph = orbit.get_ephemeris(constellation, prn, tgps.mjd)
# Réponses
orbit.orb_from_eph(constellation, prn, tgps.mjd)
solutions = orbit.debug.__dict__


print("Réponses")
(X, Y, Z), dts = orbit.get_sat_coords(constellation, prn, tgps.mjd)
print(f"X = {X:.3f}m\nY = {Y:.3f} m\nZ = {Z:.3f} m\ndte = {dts:.9f} s")

print("\nSolutions:")
Xs, Ys, Zs = solutions["X_ECEF"].flatten()
dtss = solutions["dte"]
print(f"X = {Xs:.3f}m\nY = {Ys:.3f} m\nZ = {Zs:.3f} m\ndte = {dtss:.9f} s")

# Correct ?
tolerance = 1e-06
X_ECEF = np.array([X, Y, Z])
X_ECEFs = np.array([Xs, Ys, Zs])
if np.allclose(X_ECEF, X_ECEFs, atol=tolerance) and abs(dts - dtss) < tolerance:
    print("\nCorrect!")
else:
    print("\nIncorrect. Il semble y avoir une erreur.")
