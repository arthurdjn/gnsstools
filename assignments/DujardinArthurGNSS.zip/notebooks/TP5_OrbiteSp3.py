# File: TP5_OrbiteSp3.py
# Creation: Saturday January 23rd 2021
# Author: Arthur Dujardin
# ------
# Copyright (c) 2021 Arthur Dujardin


# Imports
import os
import numpy as np
from gpstime import gpstime
import gnsstoolbox.orbits as orbits

# TP5
from gnss import OrbitSP3


# Création d'un objet orbite
orbit = OrbitSP3()
orbit.load_sp3("data/COM20225_15M.SP3")


# Objet Temps qui permet des conversion (secondes - mjd etc)
tgps = gpstime(yyyy=2018, doy=285, dsec=5435)
# Selection de la constellation
constellation = "G"
# Satellite
prn = 14

# Ordre
order = 9


print("Réponses")
(X, Y, Z), dts = orbit.get_sat_sp3(constellation, prn, tgps.mjd, order)
print(f"X = {X:.3f}m\nY = {Y:.3f} m\nZ = {Z:.3f} m\ndte = {dts:.9f} s")

print("\nSolutions:")
Xs, Ys, Zs, dtss = orbit.orb_sp3_Lagrange(constellation, prn, tgps.mjd, order)
print(f"X = {Xs:.3f}m\nY = {Ys:.3f} m\nZ = {Zs:.3f} m\ndte = {dtss:.9f} s")

# Correct ?
tolerance = 1e-06
XYZ = np.array([X, Y, Z])
XYZs = np.array([Xs, Ys, Zs])
if np.allclose(XYZ, XYZs, atol=tolerance) and abs(dts - dtss) < tolerance:
    print("\nCorrect!")
else:
    print("\nIncorrect. Il semble y avoir une erreur.")
