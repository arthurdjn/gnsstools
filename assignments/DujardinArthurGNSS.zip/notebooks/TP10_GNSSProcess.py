# File: TP10_GNSSProcess.py
# Creation: Saturday January 23rd 2021
# Author: Arthur Dujardin
# ------
# Copyright (c) 2021 Arthur Dujardin


# Imports
import os
import numpy as np
from gpstime import gpstime
import gnsstoolbox.rinex_o as rx
from gnsstoolbox.gnss_process import gnss_process

# TP10 + TP3 + TP7
from gnss import GNSSProcess, Orbit
from gnss.const import DEG2RAD

orbit = Orbit()
orbit.load_rinex_n("data/BRDC00IGS_R_20182850000_01D_MN.rnx")

sp3 = Orbit()
sp3.load_sp3("data/COM20225_15M.SP3")

rnx = rx.rinex_o()
ret = rnx.load_rinex_o("data/edf1285b.18o")

# Objet Temps qui permet des conversion (secondes - mjd etc)
tgps = gpstime(yyyy=2018, doy=285, dsec=5400)
# Selection de la constellation
constellation = "G"
# Satellite
prn = 14
# Ephemeride associée
eph = orbit.get_ephemeris(constellation, prn, tgps.mjd)
# Epoque
epoch = rnx.get_epoch_by_mjd(tgps.mjd)
# Contraintes
constraint = 0
# Cut Off (radians)
cut_off = 10 * DEG2RAD
# Coordinates
x_sat = rnx.headers[0].X
y_sat = rnx.headers[0].Y
z_sat = rnx.headers[0].Z
X0 = np.column_stack((x_sat, y_sat, z_sat))

# Initial state...
spp1 = GNSSProcess()

spp1.const = constellation
spp1.constraint = constraint
spp1.cut_off = cut_off
spp1.X0 = X0


print("Réponses")
(X, Y, Z), cdtr = spp1.spp(epoch, orbit)
print(f"X = {X:.3f}m\nY = {Y:.3f} m\nZ = {Z:.3f} m\ncdtr = {cdtr:.9f} s")

print("\nSolutions:")
spp2 = gnss_process()
spp2.const = constellation
epoch2 = spp2.spp(epoch, orbit)
print(f"X = {epoch2.X:.3f}m\nY = {epoch2.Y:.3f} m\nZ = {epoch2.Z:.3f} m\ndte = {epoch2.cdtr:.9f} s")
