# File: TP7_Trilateration.py
# Creation: Saturday January 23rd 2021
# Author: Arthur Dujardin
# ------
# Copyright (c) 2021 Arthur Dujardin


# Imports
import os
import numpy as np
from gnsstoolbox.gnss_process import TrilatGps

# TP7
from gnss import Trilateration


sat_coords = np.genfromtxt("data/possat.txt", skip_header=1, delimiter=",")
distances = np.genfromtxt("data/dobs.txt", skip_header=1, delimiter=",")

rec_coords = np.array([4202000, 178000, 4780000])
cdt = 0


print("Réponses")
trilat = Trilateration(sat_coords, distances, rec_coords, cdt=cdt, sigma=2)
# Coordonnées approchées
(X, Y, Z), cdtr = trilat.optimize(max_steps=20, epsilon=1e-6)
# Résidus
sigma0_2 = trilat.sigma0_2
v = trilat.v
Qx = trilat.Qx
print(f"X = {X:.3f}m\nY = {Y:.3f} m\nZ = {Z:.3f} m\ncdtr = {cdtr:.9f} s")

print("\nSolutions:")
xr, yr, zr = rec_coords
x0 = np.array([[xr], [yr], [zr], [cdt]])
Xs, Ys, Zs, cdtrs, sigma0_2s, vs, Qxs = TrilatGps(sat_coords, distances, x0)
print(f"X = {Xs:.3f}m\nY = {Ys:.3f} m\nZ = {Zs:.3f} m\ndte = {cdtrs:.9f} s")

# Correct ?
tolerance = 1e-06
XYZ = np.array([X, Y, Z])
XYZs = np.array([Xs, Ys, Zs])
if np.allclose(XYZ, XYZs, atol=tolerance) and np.allclose(Qx, Qxs, atol=tolerance) and np.allclose(v, vs, atol=tolerance) and abs(cdtr - cdtrs) < tolerance and abs(sigma0_2 - sigma0_2s) < tolerance:
    print("\nCorrect!")
else:
    print("\nIncorrect. Il semble y avoir une erreur.")
